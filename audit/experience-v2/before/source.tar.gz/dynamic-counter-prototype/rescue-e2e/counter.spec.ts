import { expect, test, type Page } from "@playwright/test";

async function start(page: Page) {
  await page.goto("/");
  await page.getByRole("button", { name: "开始新品活动周", exact: true }).click();
  await page.getByRole("button", { name: "开始营业", exact: true }).click();
  await page.getByRole("button", { name: "暂停", exact: true }).click();
}
async function consult(page: Page, name: string, product: string) {
  await page.getByRole("button", { name: "查看" + name, exact: true }).click();
  await page.getByRole("button", { name: "接待" + name, exact: true }).click();
  await page.getByRole("button", { name: "观察眼下", exact: true }).click();
  await page.getByRole("button", { name: "观察脸颊", exact: true }).click();
  await page.locator(".question-choices button").first().click();
  await page.getByRole("button", { name: product, exact: true }).click();
  await page.getByRole("button", { name: "为" + name + "试用", exact: true }).click();
}

test("the full floor-to-consultation campaign reaches the honest ending after reloads", async ({ page }) => {
  test.setTimeout(90_000);
  const errors: string[] = [];
  page.on("pageerror", error => errors.push(error.message));
  await start(page);
  const days = [
    { people: [["沈薇", "柔焦 ¥980"], ["梅女士", "修护 ¥1,680"]], event: /拒绝补登记/ },
    { people: [["小雨", "柔焦 ¥980"], ["周姐", "柔焦 ¥980"]], event: /提出平分/ },
    { people: [["赵女士", "修护 ¥1,680"], ["段小姐", "柔焦 ¥980"]], event: /换低价基础款/ },
    { people: [["安姐", "修护 ¥1,680"], ["周姐", "修护 ¥1,680"]], event: /只按额度给两套/ },
    { people: [["沈薇", "柔焦 ¥980"]], event: /把评价分给柜台/ },
  ];
  for (let day = 0; day < days.length; day++) {
    if (day > 0) {
      await page.getByRole("button", { name: "开始营业", exact: true }).click();
      await page.getByRole("button", { name: "暂停", exact: true }).click();
    }
    for (let index = 0; index < days[day].people.length; index++) {
      const [name, product] = days[day].people[index];
      await consult(page, name, product);
      if (await page.getByRole("button", { name: "先登记接待", exact: true }).count()) {
        await page.getByRole("button", { name: "让顾客确认需求", exact: true }).click();
      }
      await expect(page.getByRole("region", { name: "本单报价" })).toBeVisible();
      await page.getByRole("button", { name: "登记我的接待", exact: true }).click();
      await page.getByRole("button", { name: "提出成交", exact: true }).click();
      await expect(page.getByRole("heading", { name: name + "成交", exact: true })).toBeVisible();
      await page.getByRole("button", { name: index === days[day].people.length - 1 ? "处理闭店事件" : "回到现场", exact: true }).click();
    }
    await page.getByRole("button", { name: days[day].event }).click();
    if (day === 3) await expect(page.locator(".large-number")).toContainText("¥16,750");
    await page.reload(); // Closed-day state and all money survive, no repeated event.
    await page.getByRole("button", { name: day === 4 ? "查看活动周结局" : "进入下一天", exact: true }).click();
  }
  await expect(page.getByRole("heading", { name: "你留下了，而且没变成她们", exact: true })).toBeVisible();
  await expect(page.locator(".large-number")).toContainText("¥22,630");
  await expect(page.locator(".order-line")).toHaveCount(9);
  await page.reload();
  await expect(page.getByRole("heading", { name: "你留下了，而且没变成她们", exact: true })).toBeVisible();
  expect(errors).toEqual([]);
});

test("a saved observation and pending rival resume; a sample does not erase rejection", async ({ page }) => {
  await start(page);
  await page.getByRole("button", { name: "接待沈薇", exact: true }).click();
  await page.getByRole("button", { name: "观察眼下", exact: true }).click();
  await page.reload();
  await expect(page.getByRole("button", { name: "观察眼下", exact: true })).toHaveAttribute("aria-pressed", "true");
  await page.getByRole("button", { name: "观察脸颊", exact: true }).click();
  await page.getByLabel("对顾客说", { exact: true }).fill("镜头里你最介意粉感吗？");
  await page.getByRole("button", { name: "开口问", exact: true }).click();
  await page.getByRole("button", { name: "修护 ¥1,680", exact: true }).click();
  await page.getByRole("button", { name: "为沈薇试用", exact: true }).click();
  await page.reload();
  await expect(page.getByRole("button", { name: "先登记接待", exact: true })).toBeVisible();
  const rival = await page.getByLabel("竞品打断").boundingBox();
  const face = await page.locator(".portrait-window").boundingBox();
  expect(rival!.y).toBeGreaterThanOrEqual(face!.y + face!.height);
  await page.getByRole("button", { name: "先登记接待", exact: true }).click();
  await page.getByRole("button", { name: "留小样 · 8", exact: true }).click();
  await expect(page.getByRole("button", { name: "接受拒绝", exact: true })).toBeVisible();
  await page.getByRole("button", { name: "接受拒绝", exact: true }).click();
  await expect(page.getByRole("heading", { name: "沈薇拒绝成交", exact: true })).toBeVisible();
  await expect(page.locator(".large-number")).toHaveText("+ ¥0");
});

test("a split sale shows and persists the actual credited amount", async ({ page }) => {
  await start(page);
  await consult(page, "沈薇", "柔焦 ¥980");
  await page.getByRole("button", { name: "让她演示", exact: true }).click();
  await expect(page.getByLabel("本单报价")).toContainText("你入账 ¥1,430");
  await page.getByRole("button", { name: "提出成交", exact: true }).click();
  await expect(page.locator(".large-number")).toHaveText("+ ¥1,430");
  await page.reload();
  await expect(page.locator(".rail-sales")).toContainText("¥1,430");
});

test("floor acceleration consumes patience and pause freezes it", async ({ page }) => {
  await page.clock.install();
  await start(page);
  await page.clock.fastForward(60_000);
  await expect(page.locator(".shift-clock strong")).toHaveText("19:00");
  await page.getByRole("button", { name: "4×", exact: true }).click();
  await page.clock.runFor(20_000);
  await expect(page.locator(".shift-clock strong")).toHaveText("19:04");
  await page.getByRole("button", { name: "暂停", exact: true }).click();
  await page.clock.fastForward(120_000);
  await expect(page.locator(".shift-clock strong")).toHaveText("19:04");
  await expect(page.locator(".floor-journal")).toContainText("陆遥带沈薇去了维珞");
});

test("phone viewport keeps face visible and key service actions usable", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await start(page);
  await consult(page, "沈薇", "柔焦 ¥980");
  await page.getByRole("button", { name: "先登记接待", exact: true }).click();
  await expect(page.getByRole("button", { name: "提出成交", exact: true })).toBeInViewport();
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth);
  expect(overflow).toBe(false);
  for (const name of ["返回现场", "提出成交", "已登记归属"]) {
    const box = await page.getByRole("button", { name, exact: true }).boundingBox();
    expect(box!.height).toBeGreaterThanOrEqual(44);
  }
  const face = await page.locator(".portrait-window").boundingBox();
  expect(face!.height).toBeGreaterThan(220);
  await page.screenshot({ path: "../audit/rescue-2026-09-08/after-phone-service.png" });
  await page.getByRole("button", { name: "提出成交", exact: true }).click();
  await expect(page.getByRole("heading", { name: "沈薇成交", exact: true })).toBeVisible();
});
